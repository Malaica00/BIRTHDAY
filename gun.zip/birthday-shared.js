'use strict';
const $ = id => document.getElementById(id);
const scenes = [...document.querySelectorAll('.scene')].map(scene=>scene.id);
let stage = document.querySelector('.scene.active').id;
function showScene(id) {
 stage = id;
 scenes.forEach(name => {$(name).hidden = name !== id; $(name).classList.toggle('active', name === id);});
 if (id === 'collageScene') {
  const origin = {x:$('story').clientWidth*.5,y:$('story').clientHeight*.55};
  document.querySelectorAll('#collageScene .sticker').forEach(sticker => {
   sticker.style.setProperty('--burst-x',`${origin.x-sticker.offsetLeft-sticker.offsetWidth/2}px`);
   sticker.style.setProperty('--burst-y',`${origin.y-sticker.offsetTop-sticker.offsetHeight/2}px`);
  });
 }
 if (id === 'collageScene') {
  $(id).tabIndex = -1;
  $(id).focus({preventScroll:true});
  return;
 }
 const focusTarget = $(id).querySelector('button,a');
 focusTarget?.focus({preventScroll:true});
}

function celebrate(){
 if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 const colors=['#d9b98e','#fff8e9','#9e3642','#cba99b','#743039'];
 $('confetti').replaceChildren(...Array.from({length:120},(_,i)=>{
  const bit=document.createElement('i');bit.className='confetto';
  bit.style.setProperty('--color',colors[i%colors.length]);
  bit.style.left=`${Math.random()*100}%`;
  bit.style.setProperty('--x',`${(Math.random()-.5)*180}px`);
  bit.style.setProperty('--y',`${innerHeight+80}px`);
  bit.style.setProperty('--r',`${Math.random()*1200-600}deg`);
  bit.style.setProperty('--delay',`${Math.random()*1.1}s`);
  bit.style.setProperty('--duration',`${2.8+Math.random()*1.2}s`);return bit;
 }));
 setTimeout(()=>$('confetti').replaceChildren(),5300);
}
