'use strict';
let finished=false;
let stream=null,context=null,micFrame=0,micPending=false,micGeneration=0;
function stopMicrophone(){
 micGeneration++;cancelAnimationFrame(micFrame);stream?.getTracks().forEach(track=>track.stop());stream=null;
 if(context){context.close().catch(()=>{});context=null;}
 micPending=false;
}
function extinguish(){
 if(finished||stage!=='cakeScene')return;
 finished=true;stopMicrophone();$('cakeImage').src='assets/cake unlit.png';$('cakeImage').alt='Birthday cake with the candles blown out';
 $('cakeInstructions').hidden=true;$('birthdayHeading').hidden=false;celebrate();
 $('announcement').textContent='Happy Birthday Aarha! Your wish is on its way.';
 setTimeout(()=>{$('nextGift').hidden=false;$('nextGift').focus({preventScroll:true});},1800);
}
$('blowButton').addEventListener('click',extinguish);
$('enableMic').addEventListener('click',async()=>{
 if(micPending||stream||finished)return;
 micPending=true;const generation=micGeneration;
 $('micStatus').textContent='allow your microphone to blow out the candles';$('enableMic').disabled=true;
 try{
  if(!navigator.mediaDevices?.getUserMedia)throw new Error('unavailable');
  const AudioContext=window.AudioContext||window.webkitAudioContext;
  if(!AudioContext)throw new Error('unavailable');
  context=new AudioContext();await context.resume();
  const input=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false},video:false});
  if(generation!==micGeneration||finished||stage!=='cakeScene'){input.getTracks().forEach(track=>track.stop());return;}
  stream=input;micPending=false;const analyser=context.createAnalyser();analyser.fftSize=2048;
  context.createMediaStreamSource(stream).connect(analyser);const data=new Float32Array(analyser.fftSize);
  let startTime=performance.now(),baseline=0,calibrationCount=0,held=0,last=startTime;
  $('micStatus').textContent='one quiet second… then make a wish';$('breathMeter').hidden=false;$('enableMic').hidden=true;
  function listen(now){
   if(!stream||finished)return;
   analyser.getFloatTimeDomainData(data);const rms=Math.sqrt(data.reduce((sum,v)=>sum+v*v,0)/data.length);
   if(now-startTime<900){baseline+=rms;calibrationCount++;}
   else{
    $('micStatus').textContent='now blow gently into your microphone';
    const threshold=Math.max(.045,(baseline/Math.max(1,calibrationCount))*2.8);
    $('breathLevel').style.width=`${Math.min(100,rms/threshold*70)}%`;
    held=rms>threshold?held+Math.min(now-last,60):Math.max(0,held-30);
    if(held>220){extinguish();return;}
   }
   last=now;micFrame=requestAnimationFrame(listen);
  }
  micFrame=requestAnimationFrame(listen);
 }catch(error){
  if(generation!==micGeneration)return;
  stopMicrophone();$('micStatus').textContent='microphone unavailable — tap below to make your wish';$('enableMic').disabled=false;
 }
});
$('nextGift').addEventListener('click',()=>{stopMicrophone();window.location.assign('gift.html');});

window.addEventListener('pagehide',stopMicrophone);
document.addEventListener('visibilitychange',()=>{if(document.hidden&&(stream||micPending)){stopMicrophone();$('enableMic').hidden=false;$('enableMic').disabled=false;$('breathMeter').hidden=true;$('micStatus').textContent='tap to enable your microphone again';}});
