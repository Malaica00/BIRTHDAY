'use strict';
let opening=false;
function unwrap(){
 if(opening||stage!=='giftScene')return;opening=true;$('present').disabled=true;$('unwrap').disabled=true;
 $('giftScene').classList.add('unwrapping');
 setTimeout(()=>{showScene('collageScene');celebrate();$('announcement').textContent='Surprise! Tap the camera to print a film strip, or the memory book to open your scrapbook.';},matchMedia('(prefers-reduced-motion: reduce)').matches?0:750);
}
$('present').addEventListener('click',unwrap);$('unwrap').addEventListener('click',unwrap);
$('envelope').addEventListener('click',()=>$('note').showModal());
[['disco','is-spinning'],['record','is-spinning'],['cat','is-dancing']].forEach(([id,cls])=>$(id).addEventListener('click',()=>{$(id).classList.toggle(cls);$(id).setAttribute('aria-pressed',String($(id).classList.contains(cls)));}));
$('love').addEventListener('click',()=>$('note').showModal());$('closeNote').addEventListener('click',()=>$('note').close());
$('note').addEventListener('click',event=>{if(event.target===$('note')){const r=$('note').getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)$('note').close();}});
const cameraDialog = $('cameraDialog');
$('camera').addEventListener('click',()=>{
 if(cameraDialog.open)return;
 cameraDialog.showModal();
 $('announcement').textContent='Your camera is printing a little strip of memories.';
});
$('closeCamera').addEventListener('click',()=>cameraDialog.close());
cameraDialog.addEventListener('click',event=>{
 if(event.target!==cameraDialog)return;
 const r=cameraDialog.getBoundingClientRect();
 if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)cameraDialog.close();
});
cameraDialog.addEventListener('close',()=>$('camera').focus({preventScroll:true}));
