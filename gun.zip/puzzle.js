'use strict';
const order = [0,1,2,3,4,5,6,7,8];
for (let i=8;i>0;i--) {const j=Math.floor(Math.random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
if (order.every((v,i)=>v===i)) [order[0],order[1]]=[order[1],order[0]];
let selected = null;
let puzzleSolved = false;
const board = $('puzzle');
function drawPuzzle() {
 board.replaceChildren(...order.map((piece,index)=>{
  const button=document.createElement('button');button.className='puzzle-piece';button.type='button';
  button.dataset.index=index;button.style.backgroundPosition=`${piece%3*50}% ${Math.floor(piece/3)*50}%`;
  button.setAttribute('aria-label',`Position ${index+1}, photo piece ${piece+1}. Select to swap.`);
  button.setAttribute('aria-pressed',String(index===selected));
  button.classList.toggle('selected',index===selected);button.classList.toggle('correct',piece===index);
  return button;
 }));
}
function swap(a,b) {
 if(puzzleSolved)return;
 [order[a],order[b]]=[order[b],order[a]];selected=null;drawPuzzle();
 if(order.every((piece,i)=>piece===i)) {
  puzzleSolved=true;board.classList.add('solved');$('puzzleHint').textContent='you did it! a little wish is on its way…';
  $('announcement').textContent='Puzzle solved! Make a wish and blow out your candles.';
  setTimeout(()=>window.location.assign('cake.html'),1000);
 }
}
board.addEventListener('click',event=>{
 const button=event.target.closest('button');if(!button||puzzleSolved)return;
 const index=Number(button.dataset.index);
 if(selected===null){selected=index;drawPuzzle();board.children[index].focus();}
 else if(selected===index){selected=null;drawPuzzle();board.children[index].focus();}
 else{swap(selected,index);board.children[index].focus();}
});
let drag=null,ignoreClick=false;
board.addEventListener('pointerdown',event=>{
 const tile=event.target.closest('button');if(!tile||puzzleSolved||event.button!==0)return;
 drag={index:Number(tile.dataset.index),x:event.clientX,y:event.clientY,id:event.pointerId};tile.setPointerCapture(event.pointerId);
});
board.addEventListener('pointerup',event=>{
 if(!drag)return;const start=drag;drag=null;
 if(Math.hypot(event.clientX-start.x,event.clientY-start.y)<12)return;
 const target=document.elementFromPoint(event.clientX,event.clientY)?.closest('.puzzle-piece');
 if(target&&board.contains(target)){swap(start.index,Number(target.dataset.index));ignoreClick=true;setTimeout(()=>ignoreClick=false,0);}
});
board.addEventListener('click',event=>{if(ignoreClick){event.stopImmediatePropagation();event.preventDefault();}},true);
board.addEventListener('pointercancel',()=>{drag=null;});
drawPuzzle();
