'use strict';
// Replace these sample photographs with personal images using “your photos”.
const samples = [
  'photo-1517841905240-472988babdf9','photo-1524504388940-b1c1722653e1',
  'photo-1529156069898-49953e39b3ac','photo-1511632765486-a01980e01a18',
  'photo-1500534623283-312aade485b7','photo-1470252649378-9c29740c9fa8',
  'photo-1511988617509-a57c8a288659','photo-1529333166437-7750a6dd5a70'
].map((id, i) => `assets/scrapbook/memory-${i + 1}.jpg`);
let sources = samples;
let current = 0;
let busy = false;
let flipbook;
let ownedURLs = [];
const pages = document.getElementById('pages');
const book = document.getElementById('book');
const previous = document.getElementById('previous');
const next = document.getElementById('next');
const photo = (n, cls = '') => `<div class="photo ${cls}"><img src="${sources[n % sources.length]}" alt="Scrapbook memory ${n + 1}" draggable="false"></div>`;
const image = n => `<img src="${sources[n % sources.length]}" alt="Scrapbook memory ${n + 1}" draggable="false">`;
function render() {
  const calendar = Array.from({length:30}, (_, i) => `<div class="day ${[3,8,11,17,21,25].includes(i) ? 'red' : ''}">${[1,4,5,7,9,12,14,16,19,20,23,26,28].includes(i) ? image(i) : ''}<small>${i + 1}</small></div>`).join('');
  const ring = Array.from({length:16}, (_, i) => {
    const a = (i / 16 * Math.PI * 2) - Math.PI / 2;
    return `<div class="photo" style="--x:${Math.cos(a)*41}%;--y:${Math.sin(a)*41}%;--r:${i*22.5-12}deg">${image(i)}</div>`;
  }).join('');
  const markup = [
    `<section class="page cover" aria-label="Page 1: Snapshot of the last 30 days"><header><span>monthly dump</span><span>with love</span></header><h1><span class="snap">Snap</span><span class="shot">— shot</span><span class="of">★ of</span><span class="last">the last</span><span class="thirty">30</span><span class="days">days.</span></h1>${photo(0,'p1')}${photo(1,'p2')}${photo(2,'p3')}${photo(3,'p4')}<footer><span>may 2026</span><span>01</span></footer></section>`,
    `<section class="page calendar" aria-label="Page 2: Our favorite memories"><header><span class="oval">current favorites<br>& core memories.</span></header><div class="star"></div><div class="calendar-grid">${calendar}</div><div class="star bottom-star"></div><span class="scribble">little moments, big feelings.</span><footer><span>a month to remember</span><span>02</span></footer></section>`,
    `<section class="page disc" aria-label="Page 3: Disc 1 memories"><header><span>Month mood.</span></header><div class="star"></div><div class="disc-ring">${ring}</div><div class="disc-label"><small>DISC 1</small>MEMORIES<small>M A Y</small></div><span class="stamp">PHOTO<br>DUMP</span><footer><span></span><span>Documenting life. &nbsp; 03</span></footer></section>`,
    `<section class="page best" aria-label="Page 4: The best of May"><h2>The<br>best<br>&nbsp; of</h2>${photo(2,'p1')}${photo(4,'p2')}${photo(0,'p3')}${photo(6,'p4')}${photo(7,'p5')}<div class="month">( &nbsp; May &nbsp; )</div><footer><span></span><span>04</span></footer></section>`,
    `<section class="page highlights" aria-label="Page 5: Life in pictures"><div class="faces">${[0,1,5,6].map(image).join('')}</div><div class="highlight-grid"><div class="tile">${image(0)}</div><div class="tile words">BIG<br>happi<br>ness.</div><div class="tile">${image(1)}</div><div class="tile words">Life<br>in<br>pictu<br>-res.</div><div class="tile">${image(2)}</div><div class="tile">${image(6)}</div><div class="tile">${image(7)}</div><div class="tile">${image(3)}</div><div class="tile words">High<br>ligh<br>ts.</div></div><footer><span>(to be continued)</span><span>05</span></footer></section>`
  ].join('');
  const template = document.createElement('template');
  template.innerHTML = markup;
  const sheets = [...template.content.children];
  sheets.forEach((sheet, i) => {sheet.dataset.pageIndex = i;});
  if (flipbook) {
    flipbook.updateFromHtml(sheets);
    flipbook.turnToPage(current);
  } else {
    pages.append(...sheets);
    flipbook = new St.PageFlip(pages, {
      width:350, height:500, size:'stretch',
      minWidth:370, maxWidth:370, minHeight:200, maxHeight:529,
      usePortrait:true, autoSize:false, showCover:false,
      drawShadow:true, maxShadowOpacity:.38,
      flippingTime:window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 1 : 950,
      mobileScrollSupport:true, swipeDistance:25,
      showPageCorners:true, disableFlipByClick:false,
    });
    flipbook.on('flip', event => {current = event.data; update();});
    flipbook.on('changeState', event => {
      busy = event.data === 'flipping' || event.data === 'user_fold';
      book.classList.toggle('is-turning', busy);
    });
    flipbook.loadFromHTML(sheets);
  }
  update();
}
function update() {
  pages.querySelectorAll('.page').forEach(page => {
    page.setAttribute('aria-hidden', String(Number(page.dataset.pageIndex) !== current));
  });
  book.style.setProperty('--read', current / 4);
  previous.disabled = current === 0;
  next.disabled = current === 4;
  document.getElementById('counter').textContent = `0${current + 1} / 05`;
  document.querySelectorAll('.dots button').forEach((dot, i) => {
    dot.classList.toggle('active', i === current);
    dot.setAttribute('aria-current', i === current ? 'page' : 'false');
  });
}
function turn(target) {
  if (busy || target < 0 || target > 4 || target === current) return;
  flipbook.flip(target, 'bottom');
}
previous.addEventListener('click', () => turn(current - 1));
next.addEventListener('click', () => turn(current + 1));
document.getElementById('dots').innerHTML = Array.from({length:5}, (_, i) => `<button type="button" aria-label="Go to page ${i + 1}" data-page="${i}"></button>`).join('');
document.getElementById('dots').addEventListener('click', e => {
  const dot = e.target.closest('button');
  if (dot) turn(Number(dot.dataset.page));
});
document.addEventListener('keydown', e => {
  if (e.target.matches('input')) return;
  if (e.key === 'ArrowRight') {e.preventDefault(); turn(current + 1);}
  if (e.key === 'ArrowLeft') {e.preventDefault(); turn(current - 1);}
});
// A slow swipe should turn too, even when it exceeds the folding engine's
// short flick timeout. Let a live corner fold finish before applying this.
let swipeStart = null;
book.addEventListener('touchstart', event => {
  if (event.touches.length !== 1 || busy) return;
  const touch = event.touches[0];
  swipeStart = {x:touch.clientX, y:touch.clientY, page:current};
}, {passive:true});
window.addEventListener('touchend', event => {
  if (!swipeStart || !event.changedTouches.length) return;
  const start = swipeStart;
  swipeStart = null;
  const touch = event.changedTouches[0];
  const dx = touch.clientX - start.x;
  const dy = touch.clientY - start.y;
  requestAnimationFrame(() => {
    if (!busy && current === start.page && Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)*1.5) {
      turn(current + (dx < 0 ? 1 : -1));
    }
  });
}, {passive:true});
window.addEventListener('touchcancel', () => {swipeStart = null;}, {passive:true});
document.getElementById('photos').addEventListener('change', async e => {
  if (busy) {e.target.value = ''; return;}
  const files = [...e.target.files].filter(file => file.type.startsWith('image/'));
  if (!files.length) return;
  const urls = files.map(file => URL.createObjectURL(file));
  const valid = await Promise.all(urls.map(url => new Promise(resolve => {
    const img = new Image(); img.onload = () => resolve(url); img.onerror = () => {URL.revokeObjectURL(url); resolve(null);}; img.src = url;
  })));
  const usable = valid.filter(Boolean);
  if (usable.length) {
    ownedURLs.forEach(URL.revokeObjectURL);
    ownedURLs = usable; sources = usable; render();
    document.getElementById('uploadStatus').textContent = `${usable.length} of your memories added. Photos stay in this tab until you close or reload it.`;
  } else document.getElementById('uploadStatus').textContent = 'These images could not be opened. Try JPG, PNG, or WebP photos.';
  e.target.value = '';
});
render();
